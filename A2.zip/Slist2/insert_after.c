#include "sll.h"
// Function to insert a new node with 'ndata' after the node with 'g_data'
int sl_insert_after(Slist **head, data_t g_data, data_t ndata)
{
	// Check if the list is empty
	if(*head==NULL)
		return LIST_EMPTY;

	// Initialize a temporary pointer to traverse the list
	Slist* temp= *head;

	// Traverse the list
	while(temp!=NULL)
	{
		// Check if the current node contains 'g_data'
		if(temp->data!=g_data)
		{
			// Move to the next node
			temp=temp->link;
		}
		else
		{
			// Create a new node
			Slist *new=(Slist*)malloc(sizeof(Slist));
			if(new==NULL)
				return FAILURE;
			
			// Set the data for the new node
			new->data=ndata;

			// Adjust pointers to insert the new node after the current node
			new->link=temp->link;
			temp->link=new;
			return SUCCESS;

		}

	}
	// 'g_data' not found in the list
	return DATA_NOT_FOUND;
}
