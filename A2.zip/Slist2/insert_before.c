#include "sll.h"

// Function to insert a new node with data 'ndata' before the node with data 'g_data'
int sl_insert_before(Slist **head, data_t g_data, data_t ndata)
{
	// Check if the list is empty
	if(*head==NULL)
		return LIST_EMPTY;

	// Initialize pointers to traverse the list
	Slist* temp=*head,*prev=NULL;

	// Traverse the list
	while(temp!=NULL)
	{
		// Check if the current node's data is not equal to 'g_data'
		if(temp->data!=g_data)
		{
			prev=temp;  // Update the previous pointer
			temp=temp->link; // Move to the next node
		}
		else
		{
			// Create a new node
			Slist* new=(Slist*)malloc(sizeof(Slist));
			if(new==NULL) 
				return FAILURE; // Memory allocation failed

			// Set the data of the new node
			new->data=ndata;

			// Insert the new node before the node with data 'g_data'
			if(*head==temp)
			{
				new->link=*head; // Link the new node to the current head
				*head=new; // Update the head to point to the new node
			}
			else
			{
				new->link=temp;// Link the new node to the current node
				prev->link=new;// Link the previous node to the new node
			}
			return SUCCESS;// Node insertion successful

		}
	}
	return DATA_NOT_FOUND;// Node with data 'g_data' not found in the list

}
