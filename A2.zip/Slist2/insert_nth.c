#include "sll.h"

// Function to insert a node at the nth position in a singly linked list
int sl_insert_nth(Slist **head, data_t data, data_t n)
{
	// Check if the list is empty when trying to insert at a position greater than 1
	if(*head == NULL && n > 1)
		return LIST_EMPTY;
	//If the position is negative the Failure
	if(n < 0)
	{
		return POSITION_NOT_FOUND;
	}
	//Insert at the 1st position
	if(n == 1)
	{
	    //Create a new node
		Slist *new = (Slist*)malloc(sizeof(Slist));
		//Check if the node is created successfully
		if(new == NULL)
			return FAILURE;
		
		//Update the data and link
		new->data = data;
		new->link = *head;
		*head = new;
		return SUCCESS;
	}
	
	// Insert at positions other than the 1st position
	int flag = 1; //Local variable for counting positions
	Slist *temp = *head;
	while(temp != NULL)
	{
		if(++flag == n)
		{	
		//	Create a new node
			Slist *new = (Slist*)malloc(sizeof(Slist));
			if(new == NULL)
				return FAILURE;
		//	Update the data and link fields to insert the new node	
			new->data = data;
			new->link = temp->link;
			temp->link = new;
			return SUCCESS;
		}
		else
			temp = temp->link;
	}
	// Position not found
	return POSITION_NOT_FOUND;
	

}
