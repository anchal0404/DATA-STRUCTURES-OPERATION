#include "sll.h"
// Function to delete an element from a singly linked list
int sl_delete_element(Slist **head, data_t data)
{
	// Check if the list is empty
	if(*head == NULL)
	{
		return LIST_EMPTY;
	}

	// Use a temporary pointer to traverse the list
	Slist *temp = *head;
	
	 // Check if the element to delete is in the first node
	if(temp->data == data)
	{
	   *head = temp->link; // Update the head to the next node
	    free(temp);		// Free the memory of the current node
	    return SUCCESS;
	}
	
	// Traverse the list
	while(temp != NULL)
	{
		// Check if the next node contains the element to delete
		if(temp->link != NULL && temp->link->data == data)
		{
			// Use a temporary pointer to the node to be deleted
			Slist *tempo= temp->link;
			 
			// Update the link of the previous node to skip the node to be deleted
			temp->link = temp->link->link;

			// Free the memory of the node to be deleted
			free(tempo);
			return SUCCESS;
		}
		else
		{
			// Move to the next node
			temp = temp->link;
		}
	}
	// Element not found in the list
	return DATA_NOT_FOUND;

}
