#include "sll.h"
/*Function to print the list*/
void print_list(Slist *head)
{
	//Check whether the list is empty of not
	if (head == NULL)
	{
		printf("INFO : List is empty\n");
	}
    else
    {
	    while(head)		
	    {
		    printf("%d -> ", head -> data);
		   //traverse through the list and print data
		   	head = head -> link;
	    }
		//End of the list
		printf("NULL\n");
    }
}

