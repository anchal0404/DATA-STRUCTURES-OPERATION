#ifndef SLL_H
#define SLL_H

/*Include Header Files*/
#include <stdio.h>
#include <stdlib.h>

/*Define MACROS*/
#define SUCCESS 0
#define FAILURE -1
#define LIST_EMPTY -1


typedef int data_t;

/*Defining Structure*/
typedef struct node
{
	data_t data;
	struct node *link;
}Slist;

// Function to find a node with the specified key in the linked list
int find_node(Slist **head, data_t key);

// Function to insert a node with data at the end of the linked list
int insert_at_last(Slist **head, data_t );

// Function to insert a node with data at the beginning of the linked list
int insert_at_first(Slist **head, data_t);

// Function to delete the entire linked list
int sl_delete_list(Slist **);

// Function to delete the last node in the linked list
int sl_delete_last(Slist **);

// Function to delete the first node in the linked list
int sl_delete_first(Slist **);

// Function to print the elements of the linked list
void print_list(Slist *head);

#endif
