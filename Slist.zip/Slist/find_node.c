#include "sll.h"
/*Function to find the given element in the list */
int find_node(Slist **head, data_t g_data)
{
	//Take a count variable for index of the element
	int count=1;

	//Check if the list is null or not.
	if(head==NULL)
		return LIST_EMPTY;
	//Taking a temporary pointer and assign it as head
	Slist* temp = *head;

	//Traverse through the list.
	while(temp->link!=NULL)
	{
		//Checking for the given element.
		if(temp->data==g_data)
		{
			//If found return index
			return count;
		}
		else
			//else update temp to next node address
			temp=temp->link;
		//Increment count
		count++;
	}
	//End of function
	return FAILURE;
}
