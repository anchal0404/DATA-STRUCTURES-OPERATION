#include "sll.h"
/*Function to delete the first Node of the single linked list*/
int sl_delete_first(Slist **head)
{
	if(*head==NULL)
		return LIST_EMPTY;

	//Taking a temporary pointer and assign it as head
	Slist *temp=*head;
	//Update head to the next link
	*head=temp->link;
	//free memory of the node
	free(temp);

	//End of function.
	return SUCCESS;
}
