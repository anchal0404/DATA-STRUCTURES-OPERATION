#include "sll.h"
/*Function to delete the last node of the list*/
int sl_delete_last(Slist **head)
{
	//Check the list is empty or not
	if(*head == NULL)
	{
		return LIST_EMPTY;
	}

	//Taking a temporary pointer and assign it as head and a pointer previous as NULL
	Slist* temp=*head;
	Slist* prev=NULL;

	//If list has single node
	if(temp->link==NULL)
	{
		*head=NULL;
	}
	//If list multiple nodes.
	else
	{
		while(temp->link!=NULL)
		{
			//Update previous as temp
			prev = temp;
			//Update temp to next node
			temp = temp->link;
		}
		//Update link of previous as NULL
		prev->link = NULL;
	}
	//Free the memory of the node
	free(temp);
	//End of functions
	return SUCCESS;


}
