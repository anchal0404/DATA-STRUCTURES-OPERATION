#include "sll.h"
// Function to insert a new node at the beginning of a singly linked list.
int insert_at_first(Slist **head, data_t data)
{
	//Create new node.
	Slist *new=(Slist*)malloc(sizeof(Slist));
	
	//Check whether the node is created or not.
	if(new == NULL)
		return FAILURE;

	//Update data in new node.
	new->data=data;

	//Update link of new as NULL.
	new->link=NULL;;
	if(*head!=NULL)
	{
		//Update link of new as head
		new->link=*head;
	}
 // Update the head to point to the new node.	
	*head=new;

	return SUCCESS;
}

