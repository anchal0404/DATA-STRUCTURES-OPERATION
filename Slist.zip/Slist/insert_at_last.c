#include "sll.h"

// Function to insert a node with data at the last position of a single linked list
int insert_at_last(Slist **head, data_t data)
{
	// Allocate memory for a new node
	Slist *new = (Slist*)malloc(sizeof(Slist));

	// Check if memory allocation was successful
	if(new==NULL)
		return FAILURE;
	// Assign data to the new node and set its link to NULL
	new->data=data;
	new->link=NULL;

	 // If the list is empty, make the new node the head
	if(*head ==NULL)
	{
		*head=new;
	}
	else
	{
		 // Traverse the list to find the last node
		Slist *temp = *head;
		while(temp->link!=NULL)
		{
			temp=temp->link;
		}
		// Attach the new node to the last node's link
		temp->link=new;
	}
	//End of Function
	return SUCCESS;
}

