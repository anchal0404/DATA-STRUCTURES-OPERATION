#include "sll.h"

/*Function to delete the entire singly linked list*/
int sl_delete_list(Slist **head)
{
	//Check whether the list is empty or not
	if(*head==NULL)
		return LIST_EMPTY;
	//Taking a temporary pointer and assign it as head
	Slist* temp = *head;

	//Traverse through the list till it reaches NULL.
	while(temp->link!=NULL)
	{
		//Update head to the next link and free the nodes 
		*head=temp->link;
		free(temp);
		temp=*head;
	}
	//Update head to NULL
	*head=NULL;
	//End of the Function.
	return SUCCESS;
	
}

