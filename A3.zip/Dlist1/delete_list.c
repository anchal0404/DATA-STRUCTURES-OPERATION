#include "dll.h"

// Function to delete the entire doubly linked list
int dl_delete_list(Dlist **head, Dlist **tail)
{
	 // Check if the list is empty
	if(*head==NULL)
		return LIST_EMPTY;

	// Temporary pointer to traverse the list
	Dlist* temp=*head;

	// Traverse the list and free each node
	while(temp->next!=NULL)
	{
		free(temp);
		temp=temp->next;
	}
	  // Update head and tail pointers to NULL, indicating an empty list
	*tail=*head=NULL;
	return SUCCESS;
}
