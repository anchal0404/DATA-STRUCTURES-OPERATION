#include "dll.h"

// Function to insert a node at the end of a doubly linked list
int dl_insert_last(Dlist **head, Dlist **tail, int data)
{
	// Allocate memory for a new node
	Dlist* new=(Dlist*)malloc(sizeof(Dlist));
	if(new==NULL)
		return FAILURE;// Return FAILURE if memory allocation fails
	 // Initialize the new node with the provided data
	new->data=data;
	new->prev=NULL;
	new->next=NULL;

	// Check if the list is empty
	if(*head==NULL)
	{
		// If the list is empty, set both head and tail to the new node`
		*head=new;
	}
	else
	{
		 // If the list is not empty, update the next pointer of the current tail
        // to point to the new node, and update the previous pointer of the new node
        // to point to the current tail
		(*tail)->next = new;
		new->prev=*tail;
	}
	// Update the tail to be the new node
		*tail=new;
		return SUCCESS;// Return SUCCESS to indicate successful insertion
	
}
