#include "dll.h"

// Function to delete the first node from a doubly linked list
int dl_delete_first(Dlist **head, Dlist **tail)
{
	// Check if the list is empty
	if(*head==NULL)
		return LIST_EMPTY;

	// Check if there's only one node in the list
	if(*head==*tail)
	{
		// Free the memory of the only node
		free(*head);
		*head=*tail=NULL;// Set head and tail to NULL as the list is now empty
	}
	else
	{
		Dlist* temp=*head;// Temporary pointer to the first node
		*head=temp->next;// Update the head to point to the next node
		free(temp);// Free the memory of the first node
		(*head)->prev=NULL;// Update the previous pointer of the new head to NULL
	}
	return SUCCESS;// Return success
}
