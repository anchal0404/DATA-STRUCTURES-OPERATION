#include "dll.h"

// Function to delete the last node from a doubly linked list
int dl_delete_last(Dlist **head, Dlist **tail)
{
	// Check if the list is empty
	if(*head==NULL)
		return LIST_EMPTY;

	Dlist* temp=*tail; // Create a temporary pointer to the last node
	// Check if there is only one node in the list
	if(*head==*tail)
	{
		free(temp); // Free the memory of the only node
		*head=*tail=NULL; // Set head and tail to NULL since the list is now empty
	}

	else
	{	*tail=temp->prev;// Update the tail to the second-to-last node
		(*tail)->prev->next=NULL;// Remove the link to the last node
		free(temp); // Free the memory of the last node
	}
	return SUCCESS; //Return SUCCESS

}
