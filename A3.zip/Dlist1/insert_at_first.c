#include "dll.h"

// Function to insert a new node at the beginning of a doubly linked list
int dl_insert_first(Dlist **head, Dlist **tail, int data)
{
	// Allocate memory for a new node
	Dlist* new=(Dlist*)malloc(sizeof(Dlist));
	// Check if memory allocation was successful
	if(new==NULL)
		return FAILURE;

	// Set the data for the new node
	new->data=data;
	new->prev=NULL;
	new->next=NULL;

	 // If the list is empty, the new node becomes both the head and the tail
	if(*head==NULL)
	{
		*tail=new;
	}
	// If the list is not empty, update pointers to insert the new node at the beginning
	else
	{
		new->next=*head;
		(*head)->prev=new;
	}
	// Update the head pointer to point to the new node
	*head=new;
	return SUCCESS;
}
