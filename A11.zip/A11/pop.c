#include "stack.h"

/* Function for Poping the element */
int Pop(Stack_t *s)
{
	int element;
	 // Check if the stack is empty
	if(s->top==-1)
		return STACK_EMPTY;// Return STACK_EMPTY if the stack is empty
	else
		element = s->stack[s->top];// Retrieve the top element
	(s->top)--;// Move the top pointer to the previous position
	return element;// Return the popped element
}
