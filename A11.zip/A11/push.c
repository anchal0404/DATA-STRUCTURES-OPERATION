#include "stack.h"

/* Function for inserting the element into the stack */
int Push(Stack_t *s, int element)
{
	// Check if the stack is full
	if((s->top) == (s->capacity)-1)
		return STACK_FULL;// Return STACK_FULL if the stack is full
	(s->top)++;// Increment the top pointer
	s->stack[s->top]=element;// Insert the element at the top of the stack
	return SUCCESS;// Return SUCCESS to indicate successful insertion

}
